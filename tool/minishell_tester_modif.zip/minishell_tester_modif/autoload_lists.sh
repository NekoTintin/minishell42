printf "%s\n" bonus_* > lst_bonus
printf "%s\n" wildcat_* > lst_wildcat
printf "%s\n" common_* > lst_common
printf "%s\n" lapinou_* > lst_lapinou